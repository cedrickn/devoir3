package com.example.mohsin.customlistview;

import android.app.SearchManager;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    String mTitle[] = {"Apprendre a dessiner", "Apprendre a danser", "Apprendre le yoga", "Apprendre a apprendre", "Apprendre le bonheur"};
    String mDate[] = {"Lundi 12h00-14h00","Mardi 12h00-14h00","Mercredi 12h00-14h00","Jeudi 12h00-14h00","Vendredi 12h00-14h00"};
    String mPeriode[]={"Du 04/04 au 05/05","Du 04/04 au 05/05","Du 04/04 au 05/05","Du 04/04 au 05/05","Du 04/04 au 05/05"};
    int images[] = {R.drawable.zoom, R.drawable.zoom, R.drawable.zoom, R.drawable.zoom, R.drawable.zoom};
    int images2[]={R.drawable.thumbsup, R.drawable.thumbsup,R.drawable.thumbsup,R.drawable.thumbsup,R.drawable.thumbsup};
    int images3[]={R.drawable.thumbsdown, R.drawable.thumbsdown,R.drawable.thumbsdown,R.drawable.thumbsdown,R.drawable.thumbsdown};
    // so our images and other things are set in array

    // now paste some images in drawable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        // now create an adapter class

        MyAdapter adapter = new MyAdapter(this, mTitle, mDate,mPeriode, images, images2,images3);
        listView.setAdapter(adapter);
        // there is my mistake...
        // now again check this..

        // now set item click on list view
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position ==  0) {
                    Toast.makeText(MainActivity.this, "Lundi 12h00-14h00", Toast.LENGTH_SHORT).show();
                }
                if (position ==  0) {
                    Toast.makeText(MainActivity.this, "Mardi 12h00-14h00", Toast.LENGTH_SHORT).show();
                }
                if (position ==  0) {
                    Toast.makeText(MainActivity.this, "Mercredi 12h00-14h00", Toast.LENGTH_SHORT).show();
                }
                if (position ==  0) {
                    Toast.makeText(MainActivity.this, "Jeudi 12h00-14h00", Toast.LENGTH_SHORT).show();
                }
                if (position ==  0) {
                    Toast.makeText(MainActivity.this, "Vendredi 12h00-14h00", Toast.LENGTH_SHORT).show();
                }
            }
        });
        // so item click is done now check list view
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.nav_menu, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager =
                (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView =
                (SearchView) menu.findItem(R.id.app_bar_search).getActionView();
        searchView.setSearchableInfo(
                searchManager.getSearchableInfo(getComponentName()));

        return true;
    }

    class MyAdapter extends ArrayAdapter<String> {

        Context context;
        String rTitle[];
        String rDate[];
        String rPeriode[];
        int rImgs[];
        int rImgs2[];
        int rImgs3[];

        MyAdapter (Context c, String title[], String date[], String periode[], int imgs[], int imgs2[], int imgs3[]) {
            super(c, R.layout.row, R.id.textView1, title);
            this.context = c;
            this.rTitle = title;
            this.rDate = date;
            this.rPeriode= periode;
            this.rImgs = imgs;
            this.rImgs2 = imgs2;
            this.rImgs3 = imgs3;

        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row, parent, false);
            ImageView images = row.findViewById(R.id.image);
            ImageView images2= row.findViewById(R.id.image3);
            ImageView images3= row.findViewById(R.id.image4);
            TextView myTitle = row.findViewById(R.id.textView1);
            TextView myDate = row.findViewById(R.id.textView2);
            TextView myPeriode = row.findViewById(R.id.textView);

            // now set our resources on views
            images.setImageResource(rImgs[position]);
            myTitle.setText(rTitle[position]);
            myDate.setText(rDate[position]);
            myPeriode.setText(rPeriode[position]);
            images2.setImageResource(rImgs2[position]);
            images3.setImageResource(rImgs3[position]);




            return row;
        }
    }
}
